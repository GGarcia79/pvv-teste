# Relatório de testes sistêmicos

Resultado: **63 de 63 verificações aprovadas**, em 3 execuções seguidas.

Como foi testado: cinco usuários simulados (administrador, instrutor, comunicação e duas alunas) usando o app ao mesmo tempo, sobre um banco de dados simulado que aplica as mesmas regras de permissão do arquivo `firestore.rules`. Além de usar a interface, cada perfil tentou gravar e ler dados diretamente, sem passar pelos botões, para conferir se o banco bloqueia o que o perfil não pode fazer.

Mensagens: todos os envios terminam na tela “Enviar no WhatsApp” com o texto pronto. O teste confere a mensagem preparada, sem encaminhar para o WhatsApp.

## Administrador

| Verificação | Resultado |
|---|---|
| Abas visíveis (Agenda, Mar, Alertas, Mídia, Provas, Clube, Gestão) | Aprovado |
| Hub de gestão completo (painel, painelcomp, alunos, personalizar, clubepub, operacao, midia, auditoria) | Aprovado |
| Painel social abre | Aprovado |
| Painel de competição abre | Aprovado |
| Personalizar clube grava marca (Clube de teste, Rio de Janeiro) | Aprovado |
| Abrir agenda cria remadas (12 remadas) | Aprovado |
| Alerta de agenda criado | Aprovado |
| Mensagem preparada para WhatsApp (sem envio) | Aprovado |
| Pode alterar papéis da equipe | Aprovado |
| Ler fichas de alunos | Aprovado |
| Sem erros de execução | Aprovado |

## Instrutor

| Verificação | Resultado |
|---|---|
| Abas visíveis (Agenda, Mar, Alertas, Mídia, Provas, Clube, Gestão) | Aprovado |
| Hub restrito (Alunos e Operação) (alunos, operacao) | Aprovado |
| Cria remada avulsa | Aprovado |
| Mensagem de nova remada preparada (sem envio) | Aprovado |
| Cancela remada com motivo (2026-10-30_Urca_0600) | Aprovado |
| Alerta de cancelamento publicado | Aprovado |
| Reabre remada | Aprovado |
| Pode enviar alerta (Novo aviso) | Aprovado |
| Alerta gravado e mensagem preparada | Aprovado |
| Sem botões de publicar mídia | Aprovado |
| Bloqueado: alterar preços (config/clube) | Aprovado |
| Bloqueado: publicar mídia | Aprovado |
| Bloqueado: ler respostas de formulários | Aprovado |
| Permitido: consultar fichas (emergência) | Aprovado |
| Sem erros de execução | Aprovado |

## Comunicação

| Verificação | Resultado |
|---|---|
| Abas visíveis (Agenda, Mar, Alertas, Mídia, Provas, Clube, Perfil) | Aprovado |
| Hub restrito (Mídia) (midia) | Aprovado |
| Publica campanha com link do Instagram | Aprovado |
| Mensagem da campanha preparada (sem envio) | Aprovado |
| Cria formulário (modelo de competição) | Aprovado |
| Pode enviar alerta | Aprovado |
| Agenda só leitura (sem cancelar, sem agendar) | Aprovado |
| Bloqueado: criar remada | Aprovado |
| Bloqueado: ler fichas de alunos | Aprovado |
| Sem erros de execução | Aprovado |

## Aluno

| Verificação | Resultado |
|---|---|
| Abas visíveis (Agenda, Mar, Alertas, Mídia, Provas, Clube, Perfil) | Aprovado |
| Sem botões de gestão na Agenda | Aprovado |
| Agenda remada na Urca | Aprovado |
| Bloqueio de duas bases no mesmo horário (pergunta troca) | Aprovado |
| Mar: escolher dia e horário (usabilidade) | Aprovado |
| Mar: sem simulação e sem ajuste manual | Aprovado |
| Não envia alertas | Aprovado |
| Mídia só leitura | Aprovado |
| Vê formulário para responder | Aprovado |
| Clube só leitura | Aprovado |
| Perfil com Minhas remadas e ficha | Aprovado |
| Bloqueado: criar remada | Aprovado |
| Bloqueado: publicar alerta | Aprovado |
| Bloqueado: publicar mídia | Aprovado |
| Bloqueado: alterar configuração | Aprovado |
| Bloqueado: virar administrador | Aprovado |
| Bloqueado: marcar própria mensalidade como paga | Aprovado |
| Bloqueado: ler ficha de outro aluno | Aprovado |
| Permitido: atualizar própria ficha (telefone) | Aprovado |
| Sem erros de execução | Aprovado |
| Vê 'Remada cancelada' no card da agenda | Aprovado |
| Aba Alertas fica vermelha (12h) | Aprovado |
| Status cancelado em Minhas remadas | Aprovado |

## Fila

| Verificação | Resultado |
|---|---|
| Remada cheia: segunda aluna entra na fila | Aprovado |
| Vaga aberta é oferecida à primeira da fila (10 min) | Aprovado |
| Aluna confirma a vaga | Aprovado |
| Sem erros de execução | Aprovado |

## O que ainda precisa de teste com pessoas reais

- Login com Google e recuperação de senha (dependem dos servidores do Google).
- Previsão do tempo com dados reais do Open-Meteo no dia a dia.
- Biometria (digital e rosto) em diferentes modelos de celular.
- Regras de segurança no Firebase real: use o **Rules Playground** do Console do Firebase para repetir alguns dos testes de bloqueio acima.