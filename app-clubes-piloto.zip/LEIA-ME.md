# App de clubes de remada — versão piloto (Firebase)

Esta pasta é o app completo, pronto para testes com várias pessoas ao mesmo tempo: login, dados compartilhados e instalação no celular.
O Praia Vermelha Va'a (PVV) é o primeiro clube. Cada novo clube recebe o seu próprio `config.js`.

## Arquivos

| Arquivo | Para que serve |
|---|---|
| index.html | O app |
| config.js | Nome, logo e identificador do clube, e as chaves do Firebase |
| firestore.rules | Regras de segurança do banco de dados (você cola no Firebase) |
| manifest.webmanifest, sw.js | Permitem instalar o app no celular |
| icon-192.png, icon-512.png, maskable-512.png, logo.png | Ícones |

---

## Parte 1 — Criar o Firebase (cerca de 30 minutos, no computador)

1. Entre em **console.firebase.google.com** com sua conta Google e toque em **Criar um projeto**. Nome sugerido: `app-clubes-remada`. O Google Analytics pode ficar desligado.
2. No menu **Criação > Authentication**, toque em **Vamos começar** e ative dois provedores:
   - **E-mail/senha**
   - **Google** (escolha seu e-mail como e-mail de suporte)
3. Ainda em Authentication, vá em **Configurações > Domínios autorizados > Adicionar domínio** e inclua: `ggarcia79.github.io`
4. No menu **Criação > Firestore Database**, toque em **Criar banco de dados**:
   - Local: **southamerica-east1 (São Paulo)**
   - Modo: **produção**
5. No Firestore, abra a aba **Regras**, apague tudo, cole o conteúdo do arquivo `firestore.rules` e toque em **Publicar**.
6. Na engrenagem ao lado de **Visão geral do projeto**, abra **Configurações do projeto**. Em **Seus apps**, toque no ícone **</>** (Web), dê um apelido e toque em **Registrar app** (não precisa marcar Hosting).
7. O Firebase mostra um bloco `firebaseConfig` com 6 valores. Copie cada um para o lugar correspondente no `config.js`, no lugar de `COLE_AQUI`.

O plano gratuito (Spark) é suficiente para o piloto.

## Parte 2 — Publicar no GitHub

1. Abra **github.com/GGarcia79/pvv-teste/upload/main**.
2. Envie **todos os arquivos desta pasta**, incluindo o `config.js` já preenchido. Eles substituem o `index.html` antigo.
3. Toque em **Confirmar alterações** e espere 2 minutos.
4. Abra **https://ggarcia79.github.io/pvv-teste/**. Deve aparecer a tela de login com o nome do clube.

## Parte 3 — Primeiro acesso como gestão

1. No app, toque em **Criar conta** e cadastre-se.
2. No Firebase, abra **Firestore Database > Dados** e navegue: `clubes` > `pvv` > `membros` > (o documento com o seu cadastro).
3. No campo `papel`, troque `aluno` por `gestao` e salve.
4. Feche e abra o app de novo. A aba **Gestão** aparece.
5. Para dar acesso à equipe: cada pessoa cria a conta no app, e você vai em **Gestão > Operação > Equipe e permissões** e escolhe o papel:
   - **Administrador:** tudo, inclusive personalização, planos, permissões e todos os painéis.
   - **Instrutor:** cria e exclui remadas, faz check-in, cancela remadas e envia alertas. Consulta fichas para emergências.
   - **Comunicação:** alertas, mídias, campanhas, links e formulários. Não vê dados de alunos.
   - **Aluno:** usa todas as abas, agenda remadas, escolhe dia e horário no Mar, responde formulários e mantém a própria ficha.
6. Em **Gestão > Personalizar clube**, ajuste nome, logo, cor e as bases (nome, tipo, coordenadas e maré).

Daqui em diante, ninguém precisa mais mexer no Firebase para dar permissões.

## Parte 4 — Instalar no celular (teste imediato, sem loja)

- **Android (Chrome):** abra o link, toque nos três pontinhos e em **Instalar app**.
- **iPhone (Safari):** abra o link, toque em **Compartilhar** e em **Adicionar à Tela de Início**.

O app abre em tela cheia, com ícone próprio, como um aplicativo.

## Parte 5 — Versão de testes na Play Store (Android)

1. Crie a conta no **Google Play Console** (taxa única de US$ 25).
   - **Conta de organização** (com CNPJ e número D-U-N-S): não precisa do teste fechado obrigatório. É o melhor caminho para um produto que será vendido.
   - **Conta pessoal** criada depois de novembro de 2023: precisa de um teste fechado com pelo menos 12 testadores por 14 dias seguidos antes de publicar.
2. Abra **pwabuilder.com**, cole o link do app e toque em **Package for stores > Android**. Ele gera o arquivo `.aab` para a Play Store e o arquivo `assetlinks.json`.
3. Para o app abrir sem a barra de endereço, o `assetlinks.json` precisa ficar em `https://ggarcia79.github.io/.well-known/assetlinks.json`. Isso exige um repositório chamado `GGarcia79.github.io` (peça ajuda nessa etapa).
4. No Play Console, crie o app, vá em **Testes > Teste interno** (ou **Teste fechado**), envie o `.aab` e adicione os e-mails dos testadores.

## Parte 6 — iPhone (TestFlight)

- Exige a conta **Apple Developer Program** (US$ 99 por ano).
- O PWABuilder também gera um projeto para iOS, mas ele precisa ser compilado em um **Mac com Xcode**, ou em um serviço de compilação na nuvem, como o Codemagic.
- A Apple costuma recusar apps que são apenas um site. Notificações no celular e biometria ajudam na aprovação; essa etapa é a hora de ter um desenvolvedor junto.

---

## Vários clubes no mesmo app

- O mesmo endereço atende todos os clubes. Cada clube tem um link próprio, por exemplo `https://ggarcia79.github.io/pvv-teste/?clube=haka`. O app lembra o clube no celular depois do primeiro acesso.
- Os dados de cada clube ficam separados no banco (`clubes/<id>`), e as regras impedem que um clube veja o outro.
- Para implantar um clube novo: envie o link com `?clube=<id>` ao responsável, peça para ele criar a conta, e no Firebase mude o `papel` dele para `gestao` em `clubes/<id>/membros`. Depois ele personaliza nome, logo, cor, bases, planos e estrutura pelo próprio app.
- A previsão usa o Open-Meteo, que é gratuito apenas para uso não comercial. Para vender o produto, contrate o plano comercial deles.

## Atualizações depois de publicar

- Para corrigir ou melhorar o app, envie o novo `index.html` ao GitHub. Todos recebem a nova versão na próxima vez que abrirem, inclusive quem instalou pela Play Store (o app da loja carrega o site).
- Só é preciso enviar uma nova versão para a loja quando mudar algo do próprio pacote: nome, ícone ou permissões do celular.
- Recomendado: dois ambientes separados, um de **teste** e um de **produção** (dois repositórios e dois projetos no Firebase), para testar as mudanças antes de chegar aos clubes.

## Atualizar as regras

Sempre que receber um `firestore.rules` novo, cole no Firebase (Firestore > Regras) e publique. Esta versão inclui a marca pública do clube (para a tela de login) e separa a grade de horários (instrutores) das configurações do clube (só administrador).
